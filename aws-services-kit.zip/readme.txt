=== Pix Automático com Pagarme para WooCommerce ===

Contributors: marcosgomesneto
Tags: amazon, aws, upload, media, attachments, bucket, s2
Requires at least: 4.0
Requires PHP: 7.0
Tested up to: 6.4
Stable tag: 1.0.1
License: GPLv2 or later
Language: pt_BR
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Wordpress plugin integrated with Amazon AWS S3 to send files from the local 'uploads' folder to the S3 bucket.

== 1.0.0 ==

* First Version