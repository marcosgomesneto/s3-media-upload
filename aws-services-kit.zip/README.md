# Amazon AWS S3 Upload Plugin to Bucket

Wordpress plugin integrated with Amazon AWS S3 to send files from the local 'uploads' folder to the S3 bucket.

## 1.0.0

- First version